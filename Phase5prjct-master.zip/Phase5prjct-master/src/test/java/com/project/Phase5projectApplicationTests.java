package com.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase5projectApplicationTests {

	@Test
	void contextLoads() {
	}

}
